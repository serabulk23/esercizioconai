document.addEventListener('DOMContentLoaded', function() {
    // Pagina di registrazione
    const registrationForm = document.getElementById('registrationForm');
    if (registrationForm) {
        registrationForm.addEventListener('submit', function(event) {
            event.preventDefault();
            if (validateForm()) {
                saveStudentData();
            }
        });

        function validateForm() {
            let isValid = true;
            isValid = validateNameField('nome', 'Inserisci un nome valido (solo lettere).') && isValid;
            isValid = validateNameField('cognome', 'Inserisci un cognome valido (solo lettere).') && isValid;
            isValid = validateDateField('data_nascita', 'Inserisci la tua data di nascita.') && isValid;
            isValid = validateEmailField('email', 'Inserisci un\'email valida.') && isValid;
            isValid = validateSelectField('corso', 'Seleziona il tuo corso di studio.') && isValid;
            return isValid;
        }

        function validateNameField(id, errorMessage) {
            const field = document.getElementById(id);
            const errorDiv = document.getElementById(id + '-error');
            const lettersOnly = /^[A-Za-z\s]+$/; // Regex per accettare solo lettere e spazi

            if (!field.value.trim()) {
                errorDiv.textContent = `Inserisci il tuo ${id}.`;
                return false;
            } else if (!lettersOnly.test(field.value)) {
                errorDiv.textContent = errorMessage;
                return false;
            } else {
                errorDiv.textContent = '';
                return true;
            }
        }

        function validateDateField(id, errorMessage) {
            const field = document.getElementById(id);
            const errorDiv = document.getElementById(id + '-error');
            if (!field.value) {
                errorDiv.textContent = errorMessage;
                return false;
            } else {
                errorDiv.textContent = '';
                return true;
            }
        }

        function validateEmailField(id, errorMessage) {
            const field = document.getElementById(id);
            const errorDiv = document.getElementById(id + '-error');
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!field.value.trim()) {
                errorDiv.textContent = 'Inserisci la tua email.';
                return false;
            } else if (!emailRegex.test(field.value)) {
                errorDiv.textContent = errorMessage;
                return false;
            } else {
                errorDiv.textContent = '';
                return true;
            }
        }

        function validateSelectField(id, errorMessage) {
            const field = document.getElementById(id);
            const errorDiv = document.getElementById(id + '-error');
            if (!field.value) {
                errorDiv.textContent = errorMessage;
                return false;
            } else {
                errorDiv.textContent = '';
                return true;
            }
        }

        function saveStudentData() {
            const nome = document.getElementById('nome').value;
            const cognome = document.getElementById('cognome').value;
            const data_nascita = document.getElementById('data_nascita').value;
            const email = document.getElementById('email').value;
            const corso = document.getElementById('corso').value;

            const student = { nome, cognome, data_nascita, email, corso };

            let students = localStorage.getItem('students');
            students = students ? JSON.parse(students) : [];
            students.push(student);
            localStorage.setItem('students', JSON.stringify(students));

            document.getElementById('registrationForm').reset();
            const successMessage = document.getElementById('success-message');
            successMessage.style.display = 'block';
            setTimeout(() => {
                successMessage.style.display = 'none';
            }, 3000);
        }
    }

    // Pagina home (rimane invariata)
    const listaStudenti = document.getElementById('lista-studenti');
    const nessunoRegistrato = document.getElementById('nessuno-registrato');
    if (listaStudenti) {
        loadStudentData();

        function loadStudentData() {
            let students = localStorage.getItem('students');
            students = students ? JSON.parse(students) : [];

            console.log("Dati studenti caricati da localStorage:", students);

            if (students.length > 0) {
                nessunoRegistrato.style.display = 'none';
                listaStudenti.innerHTML = '';
                students.forEach((student, index) => {
                    const listItem = document.createElement('li');
                    listItem.innerHTML = `
                        <span>Nome: ${student.nome}</span>
                        <span>Cognome: ${student.cognome}</span>
                        <span>Data di Nascita: ${student.data_nascita}</span>
                        <span>Email: ${student.email}</span>
                        <span>Corso: ${student.corso}</span>
                        <button class="elimina-studente" data-index="${index}">Elimina</button>
                    `;
                    listaStudenti.appendChild(listItem);
                });

                const buttonsElimina = document.querySelectorAll('.elimina-studente');
                buttonsElimina.forEach(button => {
                    button.addEventListener('click', function() {
                        const indexDaEliminare = this.getAttribute('data-index');
                        chiediPasswordElimina(indexDaEliminare);
                    });
                });

            } else {
                nessunoRegistrato.style.display = 'block';
            }
        }

        function chiediPasswordElimina(index) {
            const password = prompt("Inserisci la password di amministratore per eliminare questo studente:");
            if (password === "sera") {
                eliminaStudente(index);
            } else if (password !== null) {
                alert("Password errata. Impossibile eliminare lo studente.");
            }
        }

        function eliminaStudente(index) {
            let students = localStorage.getItem('students');
            students = students ? JSON.parse(students) : [];

            if (index >= 0 && index < students.length) {
                students.splice(index, 1);
                localStorage.setItem('students', JSON.stringify(students));
                loadStudentData(); // Ricarica la lista degli studenti aggiornata
            }
        }
    }
});